

<?php
include "header.php";
include "side.php";


?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Dashboard</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard v1</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->


            <!-- select code....? -->
            <?php
            $conn = mysqli_connect('localhost', 'root', '','doc');


            $id = $_GET['id'];

            $selc = "SELECT * FROM `doctor` WHERE  `id`='$id'";

            $co = mysqli_query($conn, $selc);

            while ($row = mysqli_fetch_array($co)) {
                # code...

             
                $name = $row['name'];
                $title = $row['title'];
                $image = $row['image'];
            }


            ?>


            <!-- update code...? -->
            <?php
            $conn = mysqli_connect('localhost', 'root', '', 'doc');


            if (isset($_POST['submit'])) {
                # code...
                $id = $_GET['id'];



                $name = $_POST['name'];
                $title = $_POST['title'];


                $image = $_FILES['image']['name'];
                $fold = "uplod/" . $image;

                move_uploaded_file($_FILES['image']['tmp_name'], $fold);



                if ($image == "") {
                    # code...

                    $col = "UPDATE `doctor` SET`name`='$name', `title`='$title' WHERE `id`='$id'";

                    $query1 = mysqli_query($conn, $col) or die("this is not connect...?");
                } else {

                    $col = "UPDATE `dodtor` SET `image`='$fold',`name`='$name',`title`='$title' WHERE `id`='$id'";


                    $query1 = mysqli_query($conn, $col) or die("this is not connect...?");
                }
            }



            ?>
            <div class="row justify-content-center">
                <div class=" col-lg-8 shadow-lg p-5 ">
                    <h1 class="text-center ">Doctor update</h1>
                    <form method="post" action="" enctype="multipart/form-data" class="w-100">

                        <label for="img">Image section:</label>
                        <input type="file" name="image" value="<?php echo $image ?>" class="form-control w-100 ">

                        <br>

                        <br>
                        <label for="t">Name</label>
                        <input type="text" name="name" value="<?php echo $name ?>" class="form-control w-100 ">
                        <br><br>
                        <label for="t">Title</label>
                        <input type="text" name="title" value="<?php echo $title ?>" class="form-control w-100 ">
                        <br><br>


                        <input type="submit" name="submit" class="btn btn-primary  w-100">


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>










<?php
include "footer.php";
?>