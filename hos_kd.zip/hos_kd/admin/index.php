<?php
session_start();
include "header.php";
include "side.php";


?>


<?php

$conn = mysqli_connect('localhost', 'root', '', 'doc');

if (isset($_POST['submit'])) {
  # code...
  $name = $_POST['name'];
  $pass = $_POST['pass'];



  $nameresult = mysqli_query($conn, "SELECT name from session WHERE name = '$name' and pass = '$pass' ");
  $user_matched = mysqli_num_rows($nameresult);

  if ($user_matched > 0) {
    # code...
    $_SESSION['name'] = $name;


    header("location:add-about.php");
  } else {
    echo "Your Not Ragisterd...?";
  }
}
?>



<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Admin Panel</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="ragister.php">Ragister</a></li>
            <li class="breadcrumb-item active"><a href="logout.php">Logout</a></li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
      <div class="row">
        <div class="col-12 mt-5">
          <div class="row shadow-lg  mt-5">
            <div class="col-lg-6 justify-content-center p-5 ">
              <form action="" method="post" enctype="multipart/form-data">
                <label for="ragister">Username</label>
                <input type="text" name="name" class="form-control">
                <label for="login">Password</label>
                <input type="text" name="pass" class="form-control">
                <br>
                <input type="submit" name="submit" class="btn btn-primary">
              </form>

            </div>
            <div class="col-6">
              <img src="../images/about-img.jpg" alt="" class="img-fluid">
            </div>
          </div>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->





</div>










<?php
include "footer.php";
?>