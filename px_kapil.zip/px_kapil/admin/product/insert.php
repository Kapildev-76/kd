<?php

$conn = mysqli_connect('localhost', 'root', '', 'pixi');

if (isset($_POST['submit'])) {
    # code...
    $image =$_FILES['image']['name'];
    $fold ="uplod/".$image;

    move_uploaded_file($_FILES['image']['tmp_name'],$fold);

    $title = $_POST['title'];
    $des = $_POST['des'];
    $price = $_POST['price'];

    $sql = "INSERT INTO `product`(`image`,`title`,`des`,`price`)
    VALUES ('$fold','$title','$des','$price')";

    $query = mysqli_query($conn,$sql);

    header("location:select.php");
}



?>


<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>database</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<style>



</style>

<body>

  <div class="container w-100">
    <div class="row justify-content-center w-auto ml-5 p-5">
      <div class="col-lg-6 col-md-12 col-sm-12 col-12 ">
        <h1 class="text-center ">Login Page</h1>
        <form method="post" action="" enctype="multipart/form-data">
       
          <label for="img">Image section:</label>
          <input type="file" name="image" class="form-control w-50 text-center">
          <br>
       
         <label for="t">Title</label>
         <input type="text" name="title" class="form-control w-50 text-center" >
         <br>
         <label for="des">Description</label>
         <textarea class="form-control w-50 text-center" name="des" cols="30" rows="10"></textarea>
         <br><br>
         <label for="t">Price</label>
         <input type="text" name="price" class="form-control w-50 text-center" >
         <br>

          <input type="submit" name="submit" class="btn btn-primary  w-25">


        </form>
      </div>

    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
    crossorigin="anonymous"></script>
</body>

</html>