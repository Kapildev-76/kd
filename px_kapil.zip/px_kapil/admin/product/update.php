<!-- select code....? -->
<?php
            $conn = mysqli_connect('localhost', 'root','', 'pixi');


$id = $_GET['id'];

$selc = "SELECT * FROM `product` WHERE `id`='$id'";

$sql = mysqli_query($conn, $selc);

while ($row = mysqli_fetch_array($sql)) {
    # code...

    $image = $row['image'];
    $des = $row['des'];
    $title = $row['title'];
    $price = $row['price'];


}


?>


<!-- update code...? -->
<?php
            $conn = mysqli_connect('localhost', 'root','', 'pixi');


if (isset($_POST['submit'])) {
    # code...
    $id = $_GET['id'];


    $image = $_FILES['image']['name'];
    $fold = "uplod/" . $image;

    move_uploaded_file(['image']['name'], $fold);

    $des = $_POST['des'];
    $title = $_POST['title'];
    $price = $_POST['price'];


    if ($image = "") {
        # code...

        $sql1 = "UPDATE `product` SET `title`='$title',`des`='$des',`price`='$price' WHERE 1";

        $query1 = mysqli_query($conn, $sql1) or die("this is not connect...?");

        if ($sql) {
            # code...
            header("location:select.php");
        }
    } else {

        $sql1 =  "UPDATE `product` SET `image`='$fold',`title`='$title',`des`='$des',`price`='$price' WHERE 1";

        $query1 = mysqli_query($conn, $sql1) or die("this is not connect...?");

        if ($sql) {
            # code...
            header("location:select.php");
        }
    }


}



?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>database</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<style>
    form {
        background-image: url(pic.jpg);
        border: 1px solid black;
        padding: 10px;

    }

    label {
        margin-bottom: 10px;
    }
</style>

<body>

    <div class="container">
        <div class="row p-5">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 wall">
                <h1 class="text-center ">Login Page</h1>
                <form method="post" action="" enctype="multipart/form-data">
                   
                    <label for="img">Image section:</label>
                    <input type="file" name="image" value="<? echo $image ?>" class="form-control w-50 text-center">
                    <br>

                    <br>
                    <label for="des">Description</label>
                    <textarea class="form-control w-50 text-center" name="des" cols="30" rows="10" value="<? echo $des ?>"></textarea>
                    <br><br>
                    <label for="t">Title</label>
                    <input type="text" name="title" value="<? echo $title ?>" class="form-control w-50 text-center">
                    <br><br>
                    <label for="t">price</label>
                    <input type="text" name="price" value="<? echo $price ?>" class="form-control w-50 text-center">
                    <br><br>

                    <input type="submit" name="submit" class="btn btn-primary  w-25">


                </form>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
        crossorigin="anonymous"></script>
</body>

</html>