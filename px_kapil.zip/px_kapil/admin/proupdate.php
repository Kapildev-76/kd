<?php

include "header.php";
?>




<!-- select code....? -->
<?php
$conn = mysqli_connect('localhost', 'root', '', 'pixi');


$id = $_GET['id'];

$selc = "SELECT * FROM `product` WHERE  `id`='$id'";

$co = mysqli_query($conn, $selc);

while ($row = mysqli_fetch_array($co)) {
    # code...


    $des = $row['des'];
    $title = $row['title'];
    $price = $row['price'];
    $image = $row['image'];
}


?>


<!-- update code...? -->
<?php
$conn = mysqli_connect('localhost', 'root', '', 'pixi');


if (isset($_POST['submit'])) {
    # code...
    $id = $_GET['id'];
    $des = $_POST['des'];
    $title = $_POST['title'];
    $price = $_POST['price'];

    $image = $_FILES['image']['name'];
    $fold = "uplod/" . $image;

    move_uploaded_file($_FILES['image']['tmp_name'], $fold);



    if ($image == ""){
        # code...

        $col = "UPDATE `product` SET `title`='$title',`des`='$des',`price`='$price' WHERE `id`='$id'";

        $query1 = mysqli_query($conn, $col) or die("this is not connect...?");

        if ($query1) {
            # code...
            header("location:proview.php");
        }
    } else {

        $col = "UPDATE `product` SET `title`='$title',`des`='$des',`price`='$price',`image`='$fold' WHERE `id`='$id'";


        $query1 = mysqli_query($conn, $col) or die("this is not connect...?");

        if ($query1) {
            # code...
            header("location:proview.php");
        }
    }
}



?>

<div class="about-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <div class="line-dec"></div>
                    <h1>Product's Update</h1>
                </div>
            </div>

        </div>
        <div class="row mt-5 p-5">
            <div class=" col-md-12 ">
                <h1 class="text-center ">Login Page</h1>
                <form method="post" action="" enctype="multipart/form-data" class="w-100">

                    <label for="img">Image section:</label>
                    <input type="file" name="image" value="<?php echo $image ?>" class="form-control w-100 text-center">
                  
                    <br>

                    <br>
                    <label for="des">Description</label>
                    <textarea class="form-control w-100 " name="des" cols="30" rows="10"><?php echo htmlspecialchars($des) ?></textarea>
                    <br><br>
                    <label for="t">Title</label>
                    <input type="text" name="title" value="<?php echo $title ?>" class="form-control w-100 ">
                    <br><br>
                    <label for="t">price</label>
                    <input type="text" name="price" value="<?php echo $price ?>" class="form-control w-100 ">
                    <br><br>

                    <input type="submit" name="submit" class="btn btn-primary  w-100">


                </form>
            </div>
        </div>
    </div>
</div>










<?php

include "footer.php";

?>