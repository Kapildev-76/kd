<?php
include "header.php";

?>

<?php

session_start();
$conn = mysqli_connect('localhost', 'root', '', 'pixi');

if (isset($_POST['submit'])) {
    # code...
    $name = $_POST['name'];
    $pass = $_POST['pass'];


    $sel = mysqli_query($conn, "SELECT name from session WHERE name='$name' and pass='$pass'");
    $user_matched = mysqli_num_rows($sel);

    if ($user_matched > 0) {
        # code...
        $_SESSION['name'] = $name;

        header("location:proadd.php");
    } else {

        echo "You Have To First Rgister..";
    }
}



?>
<div class="container mt-5 ">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="mt-5 text-center my-3 text-primary fw-bold">Login Here</h2>
        </div>
    </div>
    <div class="row justify-content-center ">


        <div class="col-md-8 shadow-lg mb-5 p-5">
            <form method="post" action="" enctype="multipart/form-data" class="">
                <label for="t">Name</label>
                <input type="text" name="name" class="form-control w-100 ">
                <br>
                <label for="t">Password</label>
                <input type="text" name="pass" class="form-control w-100 ">
                <br>
                <button type="submit" name="submit" class="btn btn-danger btn-block rounded w-md">Login Here</button>
                <a href="ragister.php" class="btn btn-primary btn-block rounded w-md">Ragister Here</a>
            </form>
        </div>
    </div>
</div>





<?php
include "footer.php";

?>