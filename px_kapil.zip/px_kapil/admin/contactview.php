<?php 
session_start();

if (!isset($_SESSION['name'])) {
    # code...
    header("location:index.php");
}


?>


<?php
include "header.php";

?>

<div class="contact-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <a href="logout.php" class="btn btn-primary btn-block rounded w-25">Log out</a>
                <div class="section-heading">
                    <div class="line-dec"></div>
                    <h1>Contact Us</h1>
                </div>
            </div>


        </div>
    </div>
    <div class="row mt-5 p-5">
        <div class="col-md-12">
            <a href="aboutadd.php" class="btn btn-danger">Add About</a>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nmae</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Massge</th>


                        <th>Update</th>
                        <th>Delet</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    $conn = mysqli_connect('localhost', 'root', '', 'pixi');

                    $selc = "SELECT `id`,`name`,`email`,`subject`,`des` FROM `contact` WHERE 1";
                    $co = mysqli_query($conn, $selc);




                    while ($row = mysqli_fetch_array($co)) {
                        # code...
                    
                        ?>
                        <tr>
                            <td>
                                <?php echo $row['id'] ?>
                            </td>
                            <td>
                            <?php echo $row['name'] ?>
                                
                            </td>
                            <td>
                                <?php echo $row['email'] ?>
                            </td>
                            <td>
                                <?php echo $row['subject'] ?>
                            </td>
                            <td>
                                <?php echo $row['des'] ?>
                            </td>
                            <td>
                                <a href="contactupdate.php?id=<?php echo $row['id']; ?>" class="btn btn-primary"
                                    id="a1">Update</a>
                            </td>
                            <td>
                                <a href="contactdelete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"
                                    id="a2">Delet</a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>










<?php
include "footer.php";

?>