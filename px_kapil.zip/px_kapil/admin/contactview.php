<?php
session_start();

if (!isset($_SESSION['name'])) {
    # code...
    header("location:index.php");
}


?>


<?php
include "header.php";

?>

<div class="contact-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <a href="logout.php" class="btn btn-primary btn-block rounded w-25">Log out</a>
                <div class="section-heading">
                    <div class="line-dec"></div>
                    <h1>Contact Us</h1>
                </div>
            </div>


        </div>
    </div>
    <h2 class="text-center text-danger">Contact View</h2>
    <div class="row mt-5 p-5">
    
        <div class="col-md-12">
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th class="text-danger">Id</th>
                        <th class="text-primary">Nmae</th>
                        <th class="text-danger">Email</th>
                        <th class="text-primary">Subject</th>
                        <th class="text-danger">Massge</th>
                </thead>
                <tbody>
                    <?php

                    $conn = mysqli_connect('localhost', 'root', '', 'pixi');

                    $selc = "SELECT `id`,`name`,`email`,`subject`,`des` FROM `contact` WHERE 1";
                    $co = mysqli_query($conn, $selc);




                    while ($row = mysqli_fetch_array($co)) {
                        # code...

                    ?>
                        <tr>
                            <td>
                                <?php echo $row['id'] ?>
                            </td>
                            <td>
                                <?php echo $row['name'] ?>

                            </td>
                            <td>
                                <?php echo $row['email'] ?>
                            </td>
                            <td>
                                <?php echo $row['subject'] ?>
                            </td>
                            <td>
                                <?php echo $row['des'] ?>
                            </td>

                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>










<?php
include "footer.php";

?>