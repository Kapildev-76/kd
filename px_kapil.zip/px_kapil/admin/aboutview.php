<?php 
session_start();

if (!isset($_SESSION['name'])) {
    # code...
    header("location:index.php");
}


?>




<?php

include "header.php";
?>




<div class="about-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <a href="logout.php" class="btn btn-primary btn-block rounded w-25">Log out</a>
                <div class="section-heading">
                    <div class="line-dec"></div>
                    <h1>About us view</h1>
                </div>
            </div>

        </div>
        <div class="row mt-5 p-5">
            <div class="col-md-12">
            <a href="aboutadd.php" class="btn btn-danger">Add About</a>
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Image's</th>
                            <th>Title</th>
                            <th>Description</th>
                      
                            <th>Update</th>
                            <th>Delet</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $conn = mysqli_connect('localhost', 'root', '', 'pixi');

                        $selc = "SELECT `id`, `image`, `title`, `des` FROM `about` WHERE 1";
                        $co = mysqli_query($conn, $selc);




                        while ($row = mysqli_fetch_array($co)) {
                            # code...
                        
                            ?>
                            <tr>
                                <td>
                                    <?php echo $row['id'] ?>
                                </td>
                                <td>
                                    <img src="<?php echo $row['image'] ?>" alt="" width="100px" height="100px">
                                </td>
                                <td>
                                    <?php echo $row['title']?>
                                </td>
                                <td>
                                    <?php echo $row['des']?>
                                </td>
                                
                                <td>
                                    <a href="aboutupdate.php?id=<?php echo $row['id']; ?>" class="btn btn-primary"
                                        id="a1">Update</a>
                                </td>
                                <td>
                                    <a href="aboutdelete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"
                                        id="a2">Delet</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>










<?php

include "footer.php";

?>

