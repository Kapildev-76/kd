<?php
include "header.php";

?>

<?php


$conn = mysqli_connect('localhost', 'root', '', 'pixi');

if (isset($_POST['submit'])) {
    # code...
    $name = $_POST['name'];
    $pass = $_POST['pass'];

    $sel = "SELECT name from session WHERE name='$name' and pass='$pass'";
    $cont = mysqli_query($conn, $sel);
    $user_matched = mysqli_num_rows($cont);

    if ($user_matched > 0) {
        # code...
        echo "You have registed...";
    }else{
        $insert = mysqli_query($conn,"INSERT INTO `session`( `name`, `pass`) VALUES ('$name','$pass')");

        if ($insert) {
            # code...
            header("location:index.php");

        }
    }
}



?>
<div class="container mt-5 ">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="mt-5">Ragister Here</h2>
        </div>
    </div>
    <div class="row">


        <div class="col-md-12  mb-5">

            <form method="post" action="" enctype="multipart/form-data">



                <label for="t">Name</label>
                <input type="text" name="name" class="form-control w-100 ">
                <br>

                <label for="t">Password</label>
                <input type="text" name="pass" class="form-control w-100 ">
                <br>

                <button type="submit" name="submit" class="btn btn-primary btn-block rounded w-md">Ragister
                    Here</button>
               
                    <a href="index.php" class="btn btn-danger btn-block rounded w-md">Login Here</a>

            </form>
        </div>







        <?php
        include "footer.php";

        ?>