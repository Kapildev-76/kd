<?php

include "header.php";
?>




<!-- select code....? -->
<?php
 $conn = mysqli_connect('localhost', 'root','', 'pixi');


$id = $_GET['id'];

$selc = "SELECT `id`, `image`, `title`, `des` FROM `about` WHERE  `id`='$id'";

$co = mysqli_query($conn,$selc);

while ($row = mysqli_fetch_array($co)) {
    # code...

    $image = $row['image'];
    $des = $row['des'];
    $title = $row['title'];



}


?>


<!-- update code...? -->
<?php
  $conn = mysqli_connect('localhost', 'root','', 'pixi');


if (isset($_POST['submit'])) {
    # code...
    $id = $_GET['id'];



    $des = $_POST['des'];
    $title = $_POST['title'];


    $image = $_FILES['image']['name'];
    $fold = "uplod/" . $image;

    move_uploaded_file($_FILES['image']['tmp_name'], $fold);



    if ($image = "") {
        # code...

        $col = "UPDATE `about` SET `title`='$title',`des`='$des' WHERE `id`='$id'";

        $query1 = mysqli_query($conn, $col) or die("this is not connect...?");

        if ($col) {
            # code...
            header("location:aboutview.php");
        }
    } else {

        $col = "UPDATE `about` SET `image`='$fold',`title`='$title',`des`='$des' WHERE `id`='$id'";


        $query1 = mysqli_query($conn, $col) or die("this is not connect...?");

        if ($col) {
            # code...
            header("location:aboutview.php");
        }
    }


}



?>

<div class="about-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <div class="line-dec"></div>
                    <h1>About Update</h1>
                </div>
            </div>

        </div>
        <div class="row mt-5 p-5">
        <div class=" col-md-12 ">
                <h1 class="text-center ">About update</h1>
                <form method="post" action="" enctype="multipart/form-data" class="w-100">
                   
                    <label for="img">Image section:</label>
                    <input type="file" name="image" value="<?php echo $image ?>" class="form-control w-75 text-center">
                    <br>

                    <br>
                    <label for="des">Description</label>
                    <textarea class="form-control w-70 " name="des" cols="30" rows="10" value="<?php echo $des ?>"></textarea>
                    <br><br>
                    <label for="t">Title</label>
                    <input type="text" name="title" value="<?php echo $title ?>" class="form-control w-75 ">
                    <br><br>
                 

                    <input type="submit" name="submit" class="btn btn-primary  w-25">


                </form>
            </div>
        </div>
    </div>
</div>










<?php

include "footer.php";

?>

