<?php
session_start();

if (!isset($_SESSION["name"])) {
    # code...
    header("location:index.php");
}


?>

<?php
ob_start();
include "header.php";
include "side.php";


?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                <h1 class="m-0">  <img src="dist/img/logo.png" alt=""></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><a href="logout.php">Logout</a></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->

            <?php

            $conn = mysqli_connect('localhost', 'root', '', 'doco');

            if (isset($_POST['submit'])) {
                # code...
                $image = $_FILES['image']['name'];
                $fold = "uplod/" . $image;

                move_uploaded_file($_FILES['image']['tmp_name'], $fold);

                $title = $_POST['title'];
                $des = $_POST['des'];


                $sql = "INSERT INTO `treatment` (`image`,`title`,`des`)
                VALUES ('$fold','$title','$des')";

                $query = mysqli_query($conn, $sql);
if ($query) {
    # code...
    header("location:treat-view.php");
}

            }


            ?>


            <div class="row justify-content-center mt-5">
                <div class="col-md-8 shadow-lg p-5 mt-5">
                    <h1 class="text-center h2 mt-1 mb-3 text-danger">Treatment Add Page</h1>
                    <form method="post" action="" enctype="multipart/form-data">

                        <label for="img">Image section:</label>
                        <input type="file" name="image" class="form-control w-100 ">
                        <br>

                        <label for="t">Title</label>
                        <input type="text" name="title" class="form-control w-100">
                        <br>
                        <label for="des">Description</label>
                        <textarea class="form-control w-100 " name="des" cols="30" rows="10"></textarea>
                        <br><br>

                        <input type="submit" name="submit" class="btn btn-primary  w-100">


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
ob_end_flush();
include "footer.php";
?>