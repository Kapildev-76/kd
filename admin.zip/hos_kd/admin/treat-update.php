<?php
ob_start();
include "header.php";
include "side.php";

?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                <h1 class="m-0">  <img src="dist/img/logo.png" alt=""></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><a href="logout.php">Logout</a></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->


            <!-- select code....? -->
            <?php
            $conn = mysqli_connect('localhost', 'root', '', 'doco');


            $id = $_GET['id'];

            $selc = "SELECT `id`, `image`, `title`, `des` FROM `treatment` WHERE  `id`='$id'";

            $co = mysqli_query($conn, $selc);

            while ($row = mysqli_fetch_array($co)) {
                # code...
            
                $image = $row['image'];
                $des = $row['des'];
                $title = $row['title'];
            }


            ?>


            <!-- update code...? -->
            <?php
            $conn = mysqli_connect('localhost', 'root', '', 'doco');


            if (isset($_POST['submit'])) {
                # code...
                $id = $_GET['id'];



                $des = $_POST['des'];
                $title = $_POST['title'];


                $image = $_FILES['image']['name'];
                $fold = "uplod/" . $image;

                move_uploaded_file($_FILES['image']['tmp_name'], $fold);



                if ($image == "") {
                    # code...
            
                    $col = "UPDATE `treatment` SET `title`='$title',`des`='$des' WHERE `id`='$id'";

                    $query1 = mysqli_query($conn, $col) or die("this is not connect...?");


                } else {

                    $col = "UPDATE `treatment` SET `image`='$fold',`title`='$title',`des`='$des' WHERE `id`='$id'";


                    $query1 = mysqli_query($conn, $col);

                    if ($query1) {
                        # code...
                        header("location:treat-view.php");
                    }

                }
            }



            ?>
            <div class="row justify-content-center">
                <div class=" col-lg-8 shadow-lg p-5 ">
                    <h1 class="text-center ">About update</h1>
                    <form method="post" action="" enctype="multipart/form-data" class="w-100">

                        <label for="img">Image section:</label>
                        <input type="file" name="image" value="<?php echo $image ?>" class="form-control w-100 ">

                        <br>

                        <br>
                        <label for="des">Description</label>
                        <textarea class="form-control w-100 " name="des" cols="30"
                            rows="10"><?php echo htmlspecialchars($des) ?></textarea>
                        <br><br>
                        <label for="t">Title</label>
                        <input type="text" name="title" value="<?php echo $title ?>" class="form-control w-100 ">
                        <br><br>


                        <input type="submit" name="submit" class="btn btn-primary  w-100">


                    </form>
                </div>
            </div>
        </div>
    </div>






</div>










<?php
ob_end_flush();
include "footer.php";
?>