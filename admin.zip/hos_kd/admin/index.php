<?php

session_start();
$conn = mysqli_connect('localhost', 'root', '', 'doco');

if (isset($_POST['submit'])) {
  # code...
  $name = $_POST['name'];
  $pass = $_POST['pass'];


  $sel = mysqli_query($conn, "SELECT name from session WHERE name='$name' and pass='$pass'");
  $user_matched = mysqli_num_rows($sel);

  if ($user_matched > 0) {
    # code...
    $_SESSION['name'] = $name;

    header("location:add-about.php");
  } else {

    echo "You Have To First Rgister..";
  }
}



?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <title>Document</title>
</head>
<style>
  * {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
  }

  #con {
    /* background: url(img/16358496_rm314-adj-10.jpg); */
    background-repeat: no-repeat;
    background-size: cover;
    width: 100%;
    height: 100vh;
  }

  #b-img {
    width: 100%;
    height: 100vh;
  }

  #form {

    /* margin-top: 300px; */
    padding: 50px;
  }
</style>

<body>

  <div class="container-fluid" id="con">
    <div class="row">
      <div class="col-6">
        <img src="dist/img/log.jpg" id="b-img" alt="" class="img-fluid">
      </div>
      <div class="col-6 mt-5" id="form">
        <h1 class="mt-5 mb-5 text-center" >Welcome       To      <img src="dist/img/logo.png" alt=""></h1>
        <p class="border p-3 bg-danger text-white">Enter your Username & password to login</p>

        <div class="tab-content ">
          <div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
            <form action="" method="post" enctype="multipart/form-data">

              <div class="form-outline mb-4">
              <label class="form-label" for="loginName"> username</label>
                <input type="text" name="name" class="form-control" />
               
              </div>


              <div class="form-outline mb-4">
              <label class="form-label" for="loginPassword">Password</label>
                <input type="text"  name="pass" class="form-control" />
              
              </div>




              <button type="submit" name="submit" class="btn btn-primary btn-block mb-4">Log in</button>

              <!-- Register buttons -->
              <div class="text-center">
                <p>Not a member? <a href="ragister.php">Register</a></p>
              </div>
            </form>
          </div>

        </div>

      </div>

    </div>
  </div>













  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
    crossorigin="anonymous"></script>
</body>

</html>