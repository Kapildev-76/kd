
<?php
include "header.php";
?>



<?php

    $conn = mysqli_connect('localhost', 'root', '', 'pixi');

    if (isset($_POST['submit'])) {
      # code...
      $image = $_FILES['image']['name'];
      $fold = "uplod/" . $image;

      move_uploaded_file($_FILES['image']['tmp_name'], $fold);

      $title = $_POST['title'];
      $des = $_POST['des'];


      $sql = "INSERT INTO `about`(`image`,`title`,`des`)
    VALUES ('$fold','$title','$des')";

      $query = mysqli_query($conn, $sql);

      header("location:aboutview.php");
    }



    ?>



<div class="about-page">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12">
        <div class="section-heading">
          <div class="line-dec"></div>
          <h1>About us</h1>
        </div>
      </div>

    </div>
    <div class="row justify-content-center">
      <div class="col-md-8 shadow-lg p-5">
        <h1 class="text-center h2 mt-1 mb-3 ">About View Page</h1>
        <form method="post" action="" enctype="multipart/form-data">

          <label for="img">Image section:</label>
          <input type="file" name="image" class="form-control w-100 ">
          <br>

          <label for="t">Title</label>
          <input type="text" name="title" class="form-control w-100">
          <br>
          <label for="des">Description</label>
          <textarea class="form-control w-100 " name="des" cols="30" rows="10"></textarea>
          <br><br>


          <input type="submit" name="submit" class="btn btn-primary  w-100">


        </form>
      </div>
    </div>
  </div>
</div>







<?php
include "footer.php";
?>