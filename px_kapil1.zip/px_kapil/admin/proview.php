<?php 
session_start();

if (!isset($_SESSION['name'])) {
    # code...
    header("location:index.php");
}


?>

<?php
include "header.php";


?>
<!-- page content -->
<div class="right_col" role="main">

    <!-- top tiles -->
    <div class="row mt-5 justify-content-center">
        <div class="col-10 mt-5 p-5">
        <a href="logout.php" class="btn btn-primary btn-block rounded w-25 mb-5">Log out</a>

            <table class="table table-hover table-bordered table-dark text-capitalize text-center">
    <a class="btn btn-danger w-25 mb-5" href="proadd.php">Add Product's</a>

                <thead>
                    <tr>
                        <th>s no</th>
                        <th>image</th>
                        <th> price</th>
                        <th>distance</th>
                        <th>message</th>
                        <th>edit</th>
                    </tr>
                </thead>
                <?php
                $conn = mysqli_connect('localhost', 'root', '', 'pixi');

                $limit = 4;
                if (isset($_GET['page'])) {
                    $page = $_GET['page'];
                } else {
                    // next page
                    $page = 1;
                }
                $offset = ($page - 1) * $limit;
                /* select query of user table with offset and limit */
                $sql = "SELECT * FROM product ORDER BY id DESC LIMIT {$offset},{$limit}";


                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    ?>
                    <?php
                    $num = 1;
                    while ($row = mysqli_fetch_array($result)) {


                        ?>
                        <tbody>
                            <tr>
                                <td>
                                    <?php echo $num ?>
                                </td>
                                <td><img src="<?php echo $row['image'] ?>" height="100px" width="100px" alt=""></td>
                                <td>
                                    <?php echo $row['price'] ?>
                                </td>
                                <td>
                                    <?php echo $row['title'] ?>
                                </td>
                                <td>
                                    <?php echo $row['des'] ?>
                                </td>
                                <td><a class="text-danger" href="proupdate.php?id=<?php echo $row['id'] ?>">update</a> <a
                                        href="prodelet.php?id=<?php echo $row['id'] ?>">delete</a></td>

                            </tr>
                            <?php
                            $num++;
                    } ?>
                        <?php
                } else {
                    echo "<h3>No Results Found.</h3>";
                }
                // show pagination
                $sql1 = "SELECT * FROM product";
                $result1 = mysqli_query($conn, $sql1) or die("Query Failed.");

                if (mysqli_num_rows($result1) > 0) {

                    $total_records = mysqli_num_rows($result1);

                    $total_page = ceil($total_records / $limit);

                    echo '<ul class="pagination ">';
                    if ($page > 1) {
                        echo '<li class="page-item"><a class="page-link" href="proview.php?page=' . ($page - 1) . '">Prev</a></li>';
                    }
                    for ($i = 1; $i <= $total_page; $i++) {
                        if ($i == $page) {
                            $active = "active";
                        } else {
                            $active = " ";
                        }
                        echo '<li class="page-item' . $active . '"><a class="page-link"  href="proview.php?page=' . $i . '">' . $i . '</a></li>';
                    }
                    if ($total_page > $page) {
                        echo '<li class="page-item"><a class="page-link" href="proview.php?page=' . ($page + 1) . '">Next</a></li>';
                    }

                    echo '</ul>';
                }
                ?>

                </tbody>
            </table>
        </div>
    </div>
   
</div>



<?php
include "footer.php";
?>