<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>database</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<style>



</style>

<body>

    <div class="container mt-5 w-100">
        <div class="row mt-5 p-5">
            <div class="col-md-12">
                <button><a href="insert.php">Insert</a></button>
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Image's</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Update</th>
                            <th>Delet</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $conn = mysqli_connect('localhost', 'root', '', 'pixi');

                        $selc = "SELECT `id`, `image`, `title`, `des`,`price` FROM `product` WHERE 1";
                        $co = mysqli_query($conn, $selc);




                        while ($row = mysqli_fetch_array($co)) {
                            # code...
                        

                            ?>
                            <tr>
                                <td>
                                    <?php echo $row['id'] ?>
                                </td>
                                <td>
                                    <img src="<?php echo $row['image'] ?>" alt="" width="100px" height="100px">
                                </td>
                                <td>
                                    <?php echo $row['title'] ?>
                                </td>
                                <td>
                                    <?php echo $row['des'] ?>
                                </td>
                                <td>
                                    <?php echo $row['price'] ?>
                                </td>
                                <td>
                                <a href="update.php?id=<?php echo $row['id']; ?>" class="btn btn-primary" id="a1">Update</a>
                            </td>
                            <td>
                                <a href="delet.php?id=<?php echo $row['id']; ?>" class="btn btn-danger" id="a2">Delet</a>
                            </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
        crossorigin="anonymous"></script>
</body>

</html>