<?php
$conn = mysqli_connect('localhost', 'root', '', 'pixi');
$id = $_GET['id'];

$del = "DELETE  FROM `product` WHERE `id`='$id' ";
$com = mysqli_query($conn, $del);


if ($com) {
    # code...
    header("location:select.php");
}


?>