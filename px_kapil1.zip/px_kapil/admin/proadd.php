<?php
include "header.php";
?>

<?php

$conn = mysqli_connect('localhost', 'root', '', 'pixi');

if (isset($_POST['submit'])) {
  # code...
 

  $title = $_POST['title'];
  $des = $_POST['des'];
  $price = $_POST['price'];
  $image = $_FILES['image']['name'];
  $fold = "uplod/" . $image;

  move_uploaded_file($_FILES['image']['tmp_name'], $fold);
  $sql = "INSERT INTO `product`(`image`,`title`,`des`,`price`)
    VALUES ('$fold','$title','$des','$price')";

  $query = mysqli_query($conn, $sql);

  header("location:proview.php");
}



?>





<div class="featured-page">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12">
        <div class="section-heading">
          <div class="line-dec"></div>
          <h1>Product Items</h1>
        </div>
      </div>

    </div>
    <div class="row justify-content-center">
      <div class="col-md-8 shadow-lg mb-5 p-5">
      
        <form method="post" action="" enctype="multipart/form-data">

          <label for="img">Image section:</label>
          <input type="file" name="image" class="form-control w-100 ">
          <br>

          <label for="t">Title</label>
          <input type="text" name="title" class="form-control w-100">
          <br>
          <label for="des">Description</label>
          <textarea class="form-control w-100" name="des" cols="30" rows="10"></textarea>
          <br><br>
          <label for="t">Price</label>
          <input type="text" name="price" class="form-control w-100 ">
          <br>

          <input type="submit" name="submit" class="btn btn-primary  w-100">


        </form>
      </div>
    </div>
  </div>
</div>







<?php
include "footer.php";
?>