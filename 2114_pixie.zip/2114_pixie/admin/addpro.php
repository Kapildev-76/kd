<?php
include("header.php");

$var = mysqli_connect("localhost", "root", "", "pixie_raman");

if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $price = $_POST['price'];

    $image = $_FILES['image']['name'];
    $fld1 = "upload/" . $image;
    $fld2 = "upload/" . $image;
    move_uploaded_file($_FILES['image']['tmp_name'], $fld2);

    $my_ins = "INSERT INTO `product`(`image`,`title`,`price`) VALUE ('$fld1','$title','$price')";

    $query = mysqli_query($var, $my_ins);

    if ($query) {
        header("location:select.php");
    }
}
?>


<div class="featured-items">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <div class="line-dec"></div>

                    <!-- form -->

                    <form action="" method="post" enctype="multipart/form-data" class="border w-50 p-3 m-auto">
                        IMAGE:
                        <input type="file" name="image"><br><br>
                        IMAGE NAME:
                        <input class="w-100" type="text" name="title" placeholder="Image Title"><br><br>
                        IMAGE PRICE:
                        <input class="w-100" type="text" name="price" placeholder="Price"><br><br>
                        <input class="btn btn-outline-success btn-lg " type="submit" name="submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
include("footer.php");

?>