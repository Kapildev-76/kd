<?php
include("header.php");

$var = mysqli_connect("localhost", "root", "", "pixie_raman");


$id = $_GET['id'];

$sql = "SELECT * FROM `product` WHERE `id` = '$id'";
$query = mysqli_query($var, $sql);
while ($row = mysqli_fetch_array($query)) {
    $image = $row['image'];
    $title = $row['title'];
    $price = $row['price'];
}

?>

<?php
$var = mysqli_connect("localhost", "root", "", "pixie_raman");
if (isset($_POST['submit'])) {

    $id = $_GET['id'];

    $title = $_POST['title'];
    $price = $_POST['price'];

    $image = $_FILES['image']['name'];
    $fld1 = "upload/" . $image;
    $fld2 = "upload/" . $image;
    move_uploaded_file($_FILES['image']['tmp_name'], $fld2);

    $sql1 = "UPDATE `product` SET `image` = '$fld1',`title` = '$title',`price` = '$price' WHERE `id` = '$id'";
    $query1 = mysqli_query($var, $sql1) or die(mysqli_error($var));

    if ($query) {
        header("location:select.php");
    }
}


?>

<div class="featured-items">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <div class="line-dec"></div>

                    <!-- form -->

                    <form action="" method="post" enctype="multipart/form-data" class="border w-50 p-3 m-auto">
                        IMAGE: <input type="file" name="image" value="<?php echo $image ?>"><br><br>
                        NAME: <input class="w-75" type="text" name="title" value="<?php echo $title ?>"><br><br>
                        PRICE: <input class="w-75" type="text" name="price" value="<?php echo $price ?>"><br><br>
                        <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
                        <input class="btn btn-outline-dark w-25" type="submit" name="submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
include("footer.php");

?>