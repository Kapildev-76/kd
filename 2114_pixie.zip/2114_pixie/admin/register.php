<?php
include("header.php");

$var = mysqli_connect("localhost", "root", "", "pixie_raman");

if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
   
    
    $sel = "select username from login where username = '$username' and password = '$password' ";
    $result = mysqli_query($var, $sel);

    $user_matched = mysqli_num_rows($result);

    if($user_matched > 0){
        echo "`try again`!!";
    }else{
        $insert = mysqli_query($var, "INSERT INTO `login` (`username`,`password`) VALUES ('$username','$password')");

        if($insert){
            header("location:login.php");
        }
    }
}

?>


<div class="featured-items">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <div class="line-dec"></div>

                    <form action="" method="post" enctype="multipart/form-data" class="border w-25 p-3">
                        <input type="text" name="username" placeholder="username"><br>
                        <input type="password" name="password" placeholder="password"><br>
                        <input type="submit" name="submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
include("footer.php");

?>