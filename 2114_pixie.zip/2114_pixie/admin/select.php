<?php
session_start();
if (!isset($_SESSION['password'])) {
    header("location:index.php");
}
?>
<?php
include("header.php");
?>

<div class="featured-items">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <div class="line-dec"></div>
                    <table class="  table table-bordered table-hover  m-auto  w-100 text-capitalize text-center table-responsive-sm">
                            <tr style="background-color:azure;" class="text-uppercase">
                                <td>sr no.</td>
                                <td>image</td>
                                <td>title</td>
                                <td>price</td>
                                <td style="color: blue;">update</td>
                                <td style="color: red;">delete</td>
                            </tr>
                        
                        <?php
                        $var = mysqli_connect("localhost", "root", "", "pixie_raman");

                        $sel = "SELECT * FROM `product`";

                        $query = mysqli_query($var, $sel);
                        $sr = 1;
                        while ($row = mysqli_fetch_array($query)) {

                        ?>
                            <tr>
                                <td><?php echo $sr   ?></td>
                                <td> <img src="<?php echo $row['image'] ?> " width="200px" alt=""> </td>
                                <td><?php echo $row['title']  ?></td>
                                <td><?php echo $row['price']  ?></td>
                                <td><a href="update.php?id=<?php echo $row['id'] ?>">update</a></td>
                                <td><a href="delete.php?id=<?php echo $row['id'] ?>">delete</a></td>
                            </tr>
                        <?php
                            $sr++;
                        }
                        ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
include("footer.php");
?>
</body>

</html>