<?php

session_start();
include("header.php");

$var = mysqli_connect("localhost", "root", "", "pixie_raman");

if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $result = mysqli_query($var, "select `username`,`password` from login where username= '$username' and password= '$password'");
    $user_matched = mysqli_num_rows($result);
    if($user_matched > 0){
        $_SESSION['password'] = $password;
        header("location:select.php");
    } else{
        echo "user not matched !!";
    }
}

?>

<div class="featured-items">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <div class="line-dec"></div>

                    <form action="" method="post" enctype="multipart/form-data" class=" w-50 m-auto">
                      USERNAME:  <input class="w-100" type="text" name="username" placeholder="username"><br><br>
                      PASSWORD:  <input class="w-100" type="password" name="password" placeholder="password"><br><br>
                        <input class="btn btn-outline-primary btn-lg btn-block" type="submit" name="submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
include("footer.php");

?>