<?php
include("header.php");

?>

<!-- Page Content -->
<!-- Banner Starts Here -->

<!-- Banner Ends Here -->

<!-- Featured Starts Here -->
<div class="featured-items">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <div class="line-dec"></div>
                    <h1></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Featred Ends Here -->


<!-- Subscribe Form Starts Here -->

<!-- Subscribe Form Ends Here -->


<?php
include("footer.php");

?>