<?php
$var = mysqli_connect("localhost", "root", "", "pixie_raman");

$id =$_GET['id'];

$del = "DELETE FROM  `product` WHERE `id` ='$id'";
$query = mysqli_query($var,$del);

if($query){
    header("location:select.php");
}

?>