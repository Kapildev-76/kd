<?php
session_start();

if (!isset($_SESSION["name"])) {
    # code...
    header("location:index.php");
}


?>


<?php
include "header.php";
include "side.php";


?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                <h1 class="m-0">  <img src="dist/img/logo.png" alt=""></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><a href="logout.php">Logout</a></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
            <div class="row bg-danger p-5 justify-content-center mt-5">
                <div class="col-10 mt-5">
                    <a href="treat-add.php" class="btn btn-primary mb-3">Add treatment details</a>
                    <table class="table table-dark">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Image's</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Update</th>
                                <th>Delet</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $conn = mysqli_connect('localhost', 'root', '', 'doco');

                            $selc = "SELECT `id`, `image`, `title`, `des` FROM `treatment` WHERE 1";
                            $co = mysqli_query($conn, $selc);




                            while ($row = mysqli_fetch_array($co)) {
                                # code...
                            
                                ?>
                                <tr>
                                    <td>
                                        <?php echo $row['id'] ?>
                                    </td>
                                    <td>
                                        <img src="<?php echo $row['image'] ?>" alt="" width="200px" height="200px">
                                    </td>
                                    <td>
                                        <?php echo $row['title'] ?>
                                    </td>
                                    <td>
                                        <?php echo $row['des'] ?>
                                    </td>

                                    <td>
                                        <a href="treat-update.php?id=<?php echo $row['id']; ?>" class="btn btn-primary"
                                            id="a1">Update</a>
                                    </td>
                                    <td>
                                        <a href="treat-delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"
                                            id="a2">Delete</a>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /top tiles -->
        </div>
        <!-- /page content -->




    </div>


</div>








<?php
include "footer.php";
?>