<?php
$conn = mysqli_connect('localhost', 'root', '', 'hos-kapil');
$id = $_GET['id'];

$del = "DELETE  FROM `about` WHERE `id`='$id' ";
$com = mysqli_query($conn, $del);


if ($com) {
    # code...
    header("location:view-about.php");
}


?>